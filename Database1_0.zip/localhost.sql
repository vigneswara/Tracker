-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 16, 2011 at 05:10 PM
-- Server version: 5.1.37
-- PHP Version: 5.2.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `it_track`
--
CREATE DATABASE `it_track` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `it_track`;

-- --------------------------------------------------------

--
-- Table structure for table `it_item`
--

CREATE TABLE `it_item` (
  `trackingNo` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `storeName` varchar(30) NOT NULL,
  `registrationDate` date NOT NULL,
  `status` varchar(10) NOT NULL,
  `price` double NOT NULL,
  `brand` varchar(30) NOT NULL,
  `model` varchar(30) NOT NULL,
  `serialNumber` varchar(30) NOT NULL,
  `ram` varchar(10) NOT NULL,
  `processor` varchar(10) NOT NULL,
  `hardDrive` varchar(10) NOT NULL,
  `screenSize` varchar(10) NOT NULL,
  `acAdapter` varchar(10) NOT NULL,
  `battery` varchar(10) NOT NULL,
  `bag` varchar(10) NOT NULL,
  `powerStatus` varchar(10) NOT NULL,
  `physicalCondition` varchar(100) NOT NULL,
  `problemDescription` varchar(100) NOT NULL,
  PRIMARY KEY (`trackingNo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `it_item`
--

INSERT INTO `it_item` VALUES(3, 'sdf', 'asdf', '123', '123123', 'viki', '1970-01-01', 'Received', 0, '3', '123', '123', '11', '2', '132', '12', '2', '2', '2', '1', 'sdf', 'asdf');
INSERT INTO `it_item` VALUES(4, '12', 'sdf12312', '12312', '123123', 'viki', '2011-09-16', 'Received', 0, '3', 'afd', 'asdf', '12', '123', '123', '123', '2', '1', '1', '1', 'xf', 'dfga');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Login` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `lockout` int(1) NOT NULL DEFAULT '0',
  `lockouttime` varchar(20) NOT NULL,
  `unlocktime` varchar(20) NOT NULL,
  `admin` int(1) NOT NULL DEFAULT '0',
  `banned` int(1) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES(4, 'viki', 'vigneswara@jahartstudio.com', 'viki', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 0, '', '', 1, 0, '2011-03-13');
